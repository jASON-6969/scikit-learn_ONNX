# Same-model CPU inference with scikit-learn and ONNX Runtime

This COMP 4330 project evaluates probability inference for one trained Random
Forest through scikit-learn and ONNX Runtime, then measures the effect of disabling
ONNX ZipMap. It studies execution and output representation; it does not train
different models to compare classification accuracy.

## Automatic experiment and Excel recording

For a shareable Windows workflow, use `Setup_Environment.cmd`, then
`Run_Experiments.cmd`. The launcher records run conditions, completes one independent
reproduction plus three sequential controlled repeats, freshly verifies each run,
and adds its results to the next free RUN in `ONNX_Experiment_Tracker.xlsx`.
`Collect_Results.cmd` creates a ZIP for returning the workbook, complete evidence
and logs. See the English [automatic experiment guide](docs/AUTO_EXPERIMENT_GUIDE.md)
for single-run commands, Excel import recovery and merging a teammate's results.

The portable recorder uses `requirements-tracker.txt` and does not require Excel or
Codex. Its modules are separate from the measured `onnx_benchmark` sources, so the
original experiment's source hashes remain valid.

For one teammate to set up an environment, reproduce the experiment once, then
complete three controlled runs on that same machine, follow the Chinese
[team experiment guide](docs/TEAM_REPRODUCTION_README.md).

## Reproduce the measured experiment

Use 64-bit Python 3.12. Run the following from this project directory in PowerShell:

```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements-lock.txt
.\.venv\Scripts\python.exe -m onnx_benchmark run --output output/reproduction
.\.venv\Scripts\python.exe -m onnx_benchmark verify --output output/reproduction
```

The lock file contains the exact packages installed for the delivered local run,
including mypy for development. `requirements.txt` describes compatible runtime
ranges; prefer the lock file when reproducing the saved results. No dataset
download, network service, GPU, or web server is needed once packages are installed.

For stable timing, use an idle machine, keep it plugged in, choose a consistent
power mode, and close other compute workloads. Record those conditions yourself;
the program does not control CPU placement, turbo behavior or OS power policy.
Timing magnitudes can vary even with the same machine and package versions.

The default run saves to `output/experiment`. Existing non-empty output directories
are rejected to preserve evidence. Use a different output path for each new run.
Figure regeneration and verification do not retrain or remeasure:

```powershell
.\.venv\Scripts\python.exe -m onnx_benchmark report --output output/experiment
.\.venv\Scripts\python.exe -m onnx_benchmark verify --output output/experiment
```

Verification writes fresh checks under `verification/`, reloads the saved models,
checks source/model hashes and split isolation, and recomputes statistics from raw
timings. If inference source files change, start a new run; an old run is evidence
for its recorded code, not for a modified implementation.

## Experimental design

| Setting | Fixed choice |
| --- | --- |
| Dataset | `sklearn.datasets.load_breast_cancer`: 569 samples, 30 features, 2 classes |
| Split | 80/20 stratified, seed 42; 455 training and 114 distinct test samples |
| Model | RandomForestClassifier, 100 trees, seed 42, `n_jobs=1`; other parameters recorded |
| Representation | Train and infer with contiguous float32 inputs |
| ONNX conversion | Requested ceilings: standard opset 17, ai.onnx.ml 3; actual imports recorded per graph |
| Variants | scikit-learn `predict_proba`, ORT ZipMap on, ORT ZipMap off |
| Batches | 1, 16, 64, 256 samples per call |
| Execution | CPU only; ORT sequential, intra/inter-op threads 1, graph optimizations enabled |
| Native libraries | threadpoolctl limits plus native thread environment variables set to 1 |
| Timing | 50 warmups; 10 rounds of 100 calls per variant per batch, rotating variant order |

Only one forest is trained. Both ONNX graphs are converted from that forest, and
the original saved forest is reloaded for the baseline. Fixed shuffled test inputs
are repeated when a batch exceeds the test set. These are artificial timing loads,
not additional independent data. Accuracy uses only the 114 original test cases.

The converter may emit older operator versions within the requested ceilings.
For the delivered run, ZipMap-on imports standard opset 9 / ai.onnx.ml 1;
ZipMap-off imports standard opset 17 / ai.onnx.ml 1. Its repeated standard import
entries are retained in the manifest. Both original converted graphs passed the
ONNX checker and executed in ORT. Requested targets should not be reported as
the actual graph versions.

Each timer covers a probability API call and the construction of its returned
objects. ORT fetches only its probability output; label inference is validated
separately. ZipMap-on materializes a sequence of dictionaries, while ZipMap-off
returns a probability tensor. Python dictionary-to-matrix normalization happens
outside timing. Input preparation, CSV output, result destruction, training,
deserialization, and session creation are excluded. Setup durations are recorded
once, separately, and do not represent cold-start distributions.

This measures the practical cost of these APIs, including scikit-learn's Python
dispatch and output handling. It is not a measurement of pure tree computation or
the isolated ZipMap operator. A downstream consumer needing another representation
may incur additional costs beyond this experiment.

## Correctness and metrics

Before benchmarking, the program checks labels and probabilities on the original
test set and all performance batches. It requires 100% agreement with scikit-learn,
finite probabilities within [0, 1], rows summing to one, and maximum absolute
probability difference at most `1e-5`. Failure saves the diagnostic JSON and stops
before timing.

Median latency, P25, P75 and P95 summarize the 1,000 call timings in each of the
12 configurations. `throughput = batch_size / median_seconds`;
`speedup = sklearn_median / compared_median`. Timing quantiles describe this
observed run; they are not confidence intervals across machines or datasets.

## Outputs and code organization

The run directory includes:

- `results.md`, `summary.csv`, and `figures/`: actual results and three charts.
- `timings.csv`: 12,000 individual timed calls with round, order and call index.
- `correctness.json`: held-out accuracy, agreement, probability errors and batch checks.
- `dataset.npz`, `dataset.json`, `batch_indices.npz`: frozen data, split and synthetic load indices.
- `random_forest.joblib`, `onnx_zipmap.onnx`, `onnx_tensor.onnx`: the same-model artifacts.
- `config.json`, `model_parameters.json`, `conversion.json`, `runtime_settings.json`:
  precise experimental choices and graph outputs.
- `environment.json`, `setup_times.json`, `provenance.json`, `status.json`:
  machine/packages, setup observations, source/artifact hashes and completion state.
- `verification/`: checks from reloading a saved run and recalculating its summary.

`onnx_benchmark` separates configuration, shared artifact helpers, data/model,
conversion, runtime adapters, prediction validation, timing, environment reporting,
plotting and orchestration. `python -m onnx_benchmark` is the entry point.
The `run`, `report` and `verify` commands accept `--output`. `run` also accepts
`--warmup`, `--rounds` and `--calls` for development checks. Reduced runs should
not be substituted for the delivered full experiment.

## Development validation

```powershell
.\.venv\Scripts\python.exe -m mypy
.\.venv\Scripts\python.exe -m mypy experiment_tools scripts/package_team_runner.py
.\.venv\Scripts\python.exe -B -m unittest discover -s tests -v
```

The tests exercise real conversion/inference, repeatable splits and loads,
prediction validation, original-output preservation and consistency between raw
timing and summary data. They are separate from the delivered full benchmark.

## Coursework documents and next steps

`output/docx/project_proposal.docx` is the editable English Word proposal, with
native text and tables. `docs/proposal.md` is its maintained source, and
`output/pdf/project_proposal.pdf` is the earlier PDF draft. Replace the team identity blanks and Member 1-5 labels with
real names/IDs before submission. Tutor acceptance of the topic does not determine
its difficulty coefficient or eventual score.

To rebuild the documents after editing the Markdown, install the separate document
dependency and run its builder:

```powershell
.\.venv\Scripts\python.exe -m pip install -r requirements-docs.txt
.\.venv\Scripts\python.exe scripts/build_proposal_docx.py
.\.venv\Scripts\python.exe scripts/build_proposal.py
```

The delivered PDF was generated with ReportLab 4.4.9 and visually checked on all
four pages. The editable DOCX was generated with python-docx 1.2.0, rendered with
Microsoft Word and visually checked on all four pages; its text and four tables
remain native editable Word content. Changes to either document should be followed
by another layout check. Direct Word edits are not synchronized back to Markdown;
rebuilding from Markdown replaces the generated DOCX.

`docs/project_plan.md` records responsibility and submission milestones. Review
the actual results, prepare the six-minute presentation and Q&A, and complete the
English final report within the official 2,000-word limit. The first local results
do not establish general speedup for other models, machines or workloads.

`docs/source_analysis.md` traces the actual installed and version-pinned upstream
implementation paths. `docs/final_report_draft.md` and
`docs/presentation_outline.md` provide an English report draft and a six-minute
presentation outline based on the saved results; review them with your team.

After verification, create a portable ZIP containing code, documents, models,
charts and original evidence (excluding the virtualenv and temporary runs):

```powershell
.\.venv\Scripts\python.exe scripts/package_project.py
```

The package includes a `MANIFEST.sha256` of its contents. It is a working project
bundle, not a completed OLE submission: member details, the formatted final report,
the actual slide deck and the team's rehearsal still need to be completed.

Official references:

- scikit-learn RandomForestClassifier:
  https://scikit-learn.org/stable/modules/generated/sklearn.ensemble.RandomForestClassifier.html
- Breast Cancer dataset:
  https://scikit-learn.org/stable/modules/generated/sklearn.datasets.load_breast_cancer.html
- sklearn-onnx ZipMap comparison:
  https://onnx.ai/sklearn-onnx/auto_examples/plot_convert_zipmap.html
- ONNX Runtime thread controls:
  https://onnxruntime.ai/docs/performance/tune-performance/threading.html

