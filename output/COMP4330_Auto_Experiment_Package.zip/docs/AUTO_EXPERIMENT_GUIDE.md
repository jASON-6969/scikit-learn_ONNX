# Automatic experiment and Excel recording guide

This package runs the same-model scikit-learn/ONNX experiment, verifies each completed run, saves a console log and run conditions, and imports the verified measurements into the next free RUN in `ONNX_Experiment_Tracker.xlsx`. All workbook labels, prompts and logs are in English.

## Quick start for a teammate

1. Install **64-bit Python 3.12**, preferably 3.12.10, from [python.org](https://www.python.org/downloads/windows/). Include the Python launcher during installation.
2. Extract the entire project ZIP to a local folder. Keep all subfolders. Do not copy another person's `.venv`.
3. Double-click **Setup_Environment.cmd** once. Internet access is needed to install the pinned packages. Wait for `Setup completed`.
4. Close **ONNX_Experiment_Tracker.xlsx** in Excel. Plug in the computer, fix its power mode, and close heavy background tasks.
5. Double-click **Run_Experiments.cmd**. Enter your name or student ID, plugged-in status, actual power mode and background workload.
6. The launcher performs **four complete runs sequentially**: one independent reproduction, followed by three controlled repeats. Each run uses a new output directory, is freshly verified, and is written to the next free workbook RUN. There is a 60-second pause between runs.
7. After all four complete, open the tracker and review the new records. The first independent reproduction is separate from the following three stability repeats.
8. Close the workbook, then double-click **Collect_Results.cmd**. Send the resulting `COMP4330_Results_...zip` from the `output` folder to the group leader.

Keep the machine and conditions the same for all four runs. The program records your conditions; it does not change the Windows power plan, pin CPU affinity or control CPU temperature. Do not run another benchmark in parallel.

Microsoft Excel and Codex are **not required** to run or record the experiment. A spreadsheet application is needed only to view/edit the workbook. Setup never starts a server and the dataset is included with scikit-learn.

## One full run from PowerShell

Open PowerShell in the extracted project folder. No environment activation is needed:

```powershell
.\.venv\Scripts\python.exe -B -X utf8 -u -m experiment_tools run --operator "Member2" --plugged-in Yes --power-mode "Best performance" --background-load "Idle; other apps closed" --purpose "Independent reproduction"
```

Use the actual observed conditions. Each command creates a distinct directory under `output/runs`. The workbook defaults to the copy at the project root. Use `--workbook "path\to\tracker.xlsx"` when maintaining a separate master tracker.

The standard measurement settings are 50 warm-ups, 10 rounds and 100 calls per round. Three backends and four batches produce 12 groups with 1,000 measurements each, or 12,000 timed calls. A smoke test can use `--warmup 3 --rounds 2 --calls 5`; it produces only 120 timed calls and must not be reported as a full benchmark.

To run the interactive launcher just once:

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\scripts\run_team_experiments.ps1 -RunCount 1
```

## What is saved automatically

| Location | Contents |
| --- | --- |
| `output/runs/<unique run>/` | Frozen data split, original forest, converted ONNX graphs, 12,000 raw timings, summary, correctness, figures, source/model provenance and fresh verification |
| `output/runs/<unique run>/run_conditions.json` | Operator, purpose, power and background conditions supplied to the runner |
| `logs/<unique workflow>/console.log` | Experiment and verification console output, including failures |
| `logs/<unique workflow>/workflow.json` | Workflow phases, commands, exit codes, timestamps, output and workbook locations |
| `logs/<unique workflow>/events.jsonl` | Timestamped workflow events |
| `ONNX_Experiment_Tracker.xlsx` | Matching Results, Run Log, run settings and Correctness records, with Excel comparison formulas |

The first historical run remains RUN-001. The initial workbook has prepared slots, and the importer expands its tables and formula ranges when those slots are exhausted. Existing measurements and human notes are preserved. The same evidence imported twice is skipped, even if its folder is moved.

Results are written only after the current verification process succeeds. Failed experiments and failed verification remain in the logs and output folder and are not marked as successful Excel records. A smoke run can be imported after successful verification, with its reduced settings visible.

## Recover an Excel import failure

If the experiment and verification pass but Excel cannot be updated, close the workbook and run **import** for the already completed directory:

```powershell
.\.venv\Scripts\python.exe -B -X utf8 -u -m experiment_tools import --output "output\runs\THE_COMPLETED_RUN_DIRECTORY"
```

Use the exact directory printed in the workflow log. This command freshly verifies the saved evidence again and imports it; it does **not** retrain or remeasure. It reuses saved run conditions unless you explicitly replace them. If the directory was imported before, it does not create a duplicate RUN.

Workbook writes use a temporary file and replacement, with an import lock for concurrent writers. If replacement is denied, keep the recoverable workbook path shown in the error and the original workbook. Do not delete the run evidence or blindly repeat the experiment.

An interrupted batch stops at that run. Keep the successful earlier runs. Retry the completed run's import if needed; use the single-run command for any additional experiments still required, recording their purpose and repeat number in `--notes`.

## Group leader: merge returned experiments

Each teammate's workbook has its own RUN numbers. Do not paste entire sheets over the master workbook. Extract their result ZIP into a separate folder and import each complete run into the master:

```powershell
.\.venv\Scripts\python.exe -B -X utf8 -u -m experiment_tools import --output "C:\ReturnedEvidence\Member2\output\runs\THE_RUN_DIRECTORY" --workbook ".\ONNX_Experiment_Tracker.xlsx"
```

Keep the returned folders after import. The importer assigns the next local RUN and keeps the evidence identity, source location, operator and original conditions. Verification requires the unchanged `onnx_benchmark` source that produced the run, so use the same project package. Different hardware is recorded separately; compare same-machine repeats together.

## Read the results correctly

- Accuracy compares predictions with the 114 ground-truth labels. Label agreement compares converted predictions with scikit-learn. They are separate metrics.
- Throughput is batch size divided by median call time. Speedup uses the matching sklearn median from the same run and batch.
- ZipMap latency reduction is `1 - tensor_median / zipmap_median`. It is a comparison of complete API/output paths, not isolated operator profiling.
- Measurements include warmed probability calls and API output construction. Training, model loading, session creation and input preparation are outside the timed region.
- A workbook record means the measurements were imported. The saved workflow log proves which command and verification were executed. Different runs or machines can produce different speeds.
- Excel formulas recalculate when opened in Excel. The Python importer preserves formulas and requests a full recalculation on open; it is not an Excel calculation engine.

## Troubleshooting

| Symptom | Action |
| --- | --- |
| Python is missing or has the wrong version | Install 64-bit Python 3.12 and use a fresh extracted folder. |
| Installation fails | Keep `logs/setup_...log` and the exact package error. Do not silently change benchmark package versions. |
| Output directory is not empty | Use the automatically generated directory or a new empty `--output` path. Existing evidence is intentionally preserved. |
| Verification fails | Keep the run directory and logs. Do not import it as a successful result or edit its summary to force a pass. |
| Workbook is open or access is denied | Close Excel, then use the import recovery command. |
| Another import is in progress | Wait for that import to finish, then retry. Remove a stale `.lock` only after confirming no importer is running. |
| New workbook formula values look blank in a viewer | Open it in Excel to recalculate formulas. The imported numeric measurements remain stored. |
