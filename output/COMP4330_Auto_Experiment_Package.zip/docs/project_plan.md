# COMP 4330SEF execution plan

Prepared 14 October 2026. Internal planning document; all dates are Hong Kong time.

## Goal and evidence standard

Compare one fixed Random Forest classifier across scikit-learn and ONNX Runtime with ZipMap enabled/disabled. Use the original held-out test set for correctness and deterministic repeated batches for performance. A valid outcome may show acceleration, slowdown or a batch-size-dependent tradeoff. No numerical result is claimed in the proposal.

## Fixed first-version scope

- Dataset: scikit-learn Breast Cancer Wisconsin (Diagnostic), 569 samples and 30 features.
- Split: stratified 80/20, seed 42; save 455 training and 114 test indices.
- Estimator: 100-tree Random Forest, seed 42, `n_jobs=1`; train once and convert the same artifact twice.
- Inputs: contiguous `float32`; batches 1, 16, 64 and 256.
- Runtime variants: scikit-learn `predict_proba`; ORT probability output only, ZipMap on/off.
- CPU only, one thread, ORT sequential execution; record dependencies, CPU, settings and artifact hashes.
- Measurement: 50 warm-ups per cell, 10 rounds with 100 calls each, rotating runtime order across rounds.
- Timing includes native API output materialization. ZipMap dictionary-to-matrix conversion is outside timing; disclose this output-format boundary.
- Validation: finite aligned class probabilities, original scikit-learn label agreement target 100%, maximum absolute probability difference at most `1e-5`.
- Out of initial scope: additional datasets/models, GPUs, multithread tuning, cold-start study and clinical performance claims.

## Milestones

| Internal target | Work | Gate |
| --- | --- | --- |
| 14-16 October | Runnable minimum experiment and proposal draft | Train, save, convert and run the same model; no unexplained correctness mismatch |
| 17 October | Review proposal | Fill group/member details; confirm scope with tutor; prepare submission |
| 19-25 October | Stabilize modules and source analysis | Repeatable full command; source locations tied to version/commit |
| 26 October-5 November | Run controlled benchmark | 12 cells, 1,000 recorded calls per cell, environment metadata and raw evidence |
| 6-14 November | Slides and six-minute rehearsal | Questions, fairness, results, tradeoffs and limitations all covered |
| Weeks 12/13-3 December | Presentation, English report, teammate rerun | Reproduce from instructions and address Q&A |
| 4 December | Final package review | Report PDF, slides, code and user guide agree on measured evidence |

Official deadlines: proposal 18 October 23:59; initial slides 15 November 23:59; final package 6 December 23:59, all in 2026. The final report must follow the course's 2,000-word maximum and 100-150-word abstract requirements. The presentation contributes 70% of the project assessment, so all members should rehearse the measured findings and limitations.

## Independent modules and review ownership

| Module or artifact | Owner placeholder | Required evidence |
| --- | --- | --- |
| Proposal/report/integration | Member 1, group leader | Completed metadata, referenced claims and complete final package |
| Data/training/source analysis | Member 2 | Saved indices, fixed model settings, no test-data fitting |
| ONNX conversion/correctness | Member 3 | Matched model artifact, class-order alignment, held-out equivalence checks |
| Benchmark/environment | Member 4 | Timing boundaries, thread settings, raw per-call data |
| Analysis/charts/slides | Member 5 | Traceable metrics, readable charts and six-minute rehearsal |

Names, student IDs, tutorial group and project group are unknown and must be filled into the proposal before submission. All five members will review adjacent work and prepare for Q&A.

## Acceptance and interpretation

1. Train once; prove both ONNX variants derive from the same saved model and split.
2. Check all 114 unduplicated held-out examples. Do not equate equal aggregate accuracy with prediction equivalence.
3. Report each correctness target separately. If a mismatch remains unexplained, stop interchangeability claims and explain the discrepancy.
4. Run all 12 cells with prepared inputs and probability-only requests. Keep conversion, session construction and data preparation outside steady-state timing.
5. Preserve raw timing and summarize median, p95, interquartile range, throughput and baseline-relative speedup.
6. Label repeated workload batches as synthetic. Do not calculate accuracy on the repeated arrays.
7. Explain relevant scikit-learn, converter and ORT source paths using pinned version/commit citations.
8. Have a teammate rerun the documented pipeline; preserve evidence even if ONNX is slower.

## Deliverables already prepared versus future work

As of 14 October, the modular program and first complete local experiment are finished: 12 cells and 12,000 timed calls. The eight automated tests and type checks pass, and the saved-run verification confirms source/model hashes, disjoint held-out samples, prediction equivalence and raw-to-summary consistency. See [the measured results](../output/experiment/results.md) and [verification](../output/experiment/verification/verification.json) for the actual evidence. The internal schedule above remains a guide for team review, independent reproduction and coursework submission rather than a claim that unfinished work has been completed.

The proposal is an editable design document and a four-page PDF. Its future-tense methodology is not experimental evidence. Source analysis, an English final-report draft, and a six-minute presentation outline are supplied separately. The group still needs to replace identity placeholders, independently review/rerun the study, prepare the formatted final report and actual slide deck, rehearse, and submit through OLE. No class presentation, independent teammate reproduction or OLE submission has been performed by the program.
