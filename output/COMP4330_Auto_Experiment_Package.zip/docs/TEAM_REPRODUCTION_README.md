# 組員實驗操作指南

已加入自動化入口：先執行根目錄的 `Setup_Environment.cmd`，再執行
`Run_Experiments.cmd`，便會依序完成下述一次獨立重現及三次同機重跑，
每次驗證成功後自動更新 Excel 並保存日誌。完成後執行 `Collect_Results.cmd`
打包交回。詳細操作、失敗恢復及合併結果見
[英文自動實驗指南](AUTO_EXPERIMENT_GUIDE.md)。以下保留原有的手動流程供核對。

由同一位組員在自己的電腦完成全部流程：先自行建立環境並獨立重現一次，成功後，再在同一台電腦、相同條件下依次做三次完整實驗。使用 Windows、PowerShell 和 64 位元 Python 3.12。

| 順序 | 由誰執行 | 要完成甚麼 |
| --- | --- | --- |
| 1：獨立重現 | 同一位組員，在自己的電腦 | 自行安裝環境，從原始碼完成一次完整實驗並驗證 |
| 2：同機重跑 | 上述同一位組員、同一台電腦 | 第一次驗證通過後，再依次做三次完整實驗，各存新資料夾 |

合共四次完整實驗：第一次獨立重現，加上之後三次穩定性測量。第一次不計入後三次的比較表。以下只會新增結果資料夾，請保留原有 `output/experiment`。

## 1. 取得專案並開啟 PowerShell

組長提供同一版本的專案原始檔和本文件。至少應有：

```text
scikit-learn_ONNX/
  README.md
  requirements-lock.txt
  onnx_benchmark/                 # 完整的 Python 模組
  docs/TEAM_REPRODUCTION_README.md
```

組員把專案解壓到自己的本機資料夾，例如 `C:\Projects\scikit-learn_ONNX`。不要複製別人的 `.venv`；虛擬環境需要在自己的電腦建立。舊的專案 ZIP 不會自動包含本次新增文件，組長分享前請確認內容。

在檔案總管進入包含 `README.md` 和 `requirements-lock.txt` 的專案根目錄，在路徑列輸入 `powershell`，按 Enter。後續指令均在這個視窗執行，不需要先啟用虛擬環境。

先確認位置：

```powershell
Get-Location
Test-Path '.\requirements-lock.txt'
Test-Path '.\onnx_benchmark\__main__.py'
```

兩個 `Test-Path` 都應顯示 `True`。若是 `False`，先進入正確的專案根目錄。

## 2. 組員自行建立環境

安裝 64 位元 Python 3.12，建議與原實驗相同的 3.12.10。可從 [Python 官方網站](https://www.python.org/downloads/windows/)取得。安裝後重新開啟 PowerShell，回到專案根目錄。

在自己解壓、沒有 `.venv` 的專案副本執行：

```powershell
py -3.12 -m venv .venv
if ($LASTEXITCODE -ne 0) { throw 'Cannot create Python 3.12 environment.' }

.\.venv\Scripts\python.exe -m pip install -r requirements-lock.txt
if ($LASTEXITCODE -ne 0) { throw 'Package installation failed. Keep the error output.' }

$memberId = 'Member2'
```

把 `Member2` 換成自己的英文名字或學號。安裝套件需要網路；安裝完成後，實驗不需要下載資料、GPU 或伺服器。若安裝失敗，保留錯誤訊息交給組長，先不要自行更換套件版本。

## 3. 固定執行條件並檢查環境

執行前插上電源，固定 Windows 電源模式，關閉遊戲、訓練、編譯及其他大量使用 CPU 的工作。一次只跑一個實驗；期間不要修改程式、套件或電源模式。這些條件需由操作人員維持，程式不會自動設定。

在同一個 PowerShell 視窗執行：

```powershell
$experimentPython = (Resolve-Path '.\.venv\Scripts\python.exe').Path

& $experimentPython -B -X utf8 -c "import sys, struct; print(sys.version); assert sys.version_info[:2] == (3, 12) and struct.calcsize('P') == 8, 'Use 64-bit Python 3.12.'"
if ($LASTEXITCODE -ne 0) { throw 'Python version or architecture is incorrect.' }

& $experimentPython -B -X utf8 -m pip check
if ($LASTEXITCODE -ne 0) { throw 'Dependency check failed.' }

& $experimentPython -B -X utf8 -m onnx_benchmark --help
if ($LASTEXITCODE -ne 0) { throw 'Cannot load the experiment. Check the project folder and packages.' }
```

應看到 Python 3.12 的版本資訊、`No broken requirements found.`，以及包含 `run`、`report`、`verify` 的指令說明。

## 4. 先獨立重現一次，再做三次完整實驗

下面指令由同一位組員執行一次：先完成 `independent_reproduction` 並驗證，通過後才繼續 `repeat_1`、`repeat_2`、`repeat_3`。每次各存新資料夾；任何一次失敗都會停止。開始時會要求填寫實際電源和背景負載狀況。

每次都是正式設定：50 次暖機、10 輪、每輪 100 次；三種執行方式乘以四種 batch，共 12 組、12,000 筆計時。每次重新訓練固定 seed 的模型，並由該次的同一模型產生兩個 ONNX 版本。

```powershell
$ErrorActionPreference = 'Stop'
if ($memberId -notmatch '^[A-Za-z0-9_-]+$') { throw 'Use letters, numbers, underscores or hyphens for memberId.' }
$runCount = 4

$powerNotes = Read-Host 'Power supply and Windows power mode (record actual conditions)'
$backgroundNotes = Read-Host 'Background workload (for example: idle; browser closed)'
if ([string]::IsNullOrWhiteSpace($powerNotes) -or [string]::IsNullOrWhiteSpace($backgroundNotes)) {
    throw 'Record power and background conditions before starting.'
}

$batchId = 'teammate_{0}_{1}_{2}' -f $memberId, (Get-Date -Format 'yyyyMMdd_HHmmss'), ([guid]::NewGuid().ToString('N').Substring(0, 8))
$resultRoot = Join-Path (Get-Location).Path ('output\' + $batchId)
New-Item -ItemType Directory -Path $resultRoot | Out-Null

[ordered]@{
    member = $memberId
    planned_runs = $runCount
    independent_reproduction_runs = 1
    stability_runs = 3
    started_at = (Get-Date).ToString('o')
    power_conditions = $powerNotes
    background_conditions = $backgroundNotes
    pause_between_runs_seconds = 60
} | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $resultRoot 'run_conditions.json') -Encoding UTF8

$comparisonRows = @()
for ($runIndex = 1; $runIndex -le $runCount; $runIndex++) {
    $runName = if ($runIndex -eq 1) { 'independent_reproduction' } else { 'repeat_' + ($runIndex - 1) }
    $runOutput = Join-Path $resultRoot $runName
    Write-Host "Starting $runName ($runIndex of $runCount) : $runOutput"

    & $experimentPython -B -X utf8 -m onnx_benchmark run --output $runOutput --warmup 50 --rounds 10 --calls 100
    if ($LASTEXITCODE -ne 0) { throw "Run $runIndex failed. Keep its folder and the error output." }

    & $experimentPython -B -X utf8 -m onnx_benchmark verify --output $runOutput
    if ($LASTEXITCODE -ne 0) { throw "Verification failed for run $runIndex. Keep its folder and the error output." }

    $status = Get-Content -LiteralPath (Join-Path $runOutput 'status.json') -Raw | ConvertFrom-Json
    $verification = Get-Content -LiteralPath (Join-Path $runOutput 'verification\verification.json') -Raw | ConvertFrom-Json
    if ($status.status -ne 'complete' -or $verification.passed -ne $true -or $verification.groups -ne 12 -or $verification.timing_rows -ne 12000) {
        throw "Run $runIndex does not meet the full experiment requirements."
    }

    if ($runIndex -gt 1) {
        $comparisonRows += Import-Csv -LiteralPath (Join-Path $runOutput 'summary.csv') |
            Select-Object @{Name='run'; Expression={$runName}}, *
    }
    Write-Host "$runName completed and verified."

    if ($runIndex -lt $runCount) {
        Write-Host 'Pause for 60 seconds. Keep the same conditions.'
        Start-Sleep -Seconds 60
    }
}

$comparisonRows | Export-Csv -LiteralPath (Join-Path $resultRoot 'comparison.csv') -NoTypeInformation -Encoding UTF8
Write-Host "All requested runs passed. Results: $resultRoot"
```

四次會依次執行，每兩次之間固定休息 60 秒；第一次成功後，後三次會自動接著執行。這個間隔不代表已控制 CPU 溫度或時脈。不要同時開多個視窗跑。若中途失敗，保留已產生的資料夾；修正問題後重新執行本節，會建立另一個新批次並從第一次開始。

## 5. 確認成功並檢查結果

每次實驗會顯示：

```text
Correctness passed on 114 distinct held-out cases
Measured batch 1: 1000 calls per variant
Measured batch 16: 1000 calls per variant
Measured batch 64: 1000 calls per variant
Measured batch 256: 1000 calls per variant
```

最後產圖時可能暫時沒有新訊息，程式沒有百分比或剩餘時間顯示。`verify` 當次輸出必須包含 `passed: true`、`groups: 12`、`timing_rows: 12000`。整段指令最後應顯示 `All requested runs passed`。

`run` 已包含圖表和結果文件。`verify` 會重載保存模型、檢查預測、檔案雜湊及摘要統計，但不重新計時。只執行 `verify` 或 `report` 不算一次獨立實驗。

同一位組員交回一個批次資料夾，包含四次獨立保存的結果：

```text
output/teammate_姓名_時間_識別碼/
  run_conditions.json
  comparison.csv
  independent_reproduction/
  repeat_1/
  repeat_2/
  repeat_3/
```

上述四個實驗資料夾各自保存完整模型、資料、原始計時及以下結果：

| 檔案 | 查看重點 |
| --- | --- |
| `results.md`、`figures/` | 可閱讀的結果、延遲與吞吐量圖表、ZipMap 比較 |
| `summary.csv` | 12 組設定，每組 `calls` 為 1,000 |
| `correctness.json` | `passed` 為 `true`；114 筆測試的標籤一致率為 1.0；機率誤差不超過 `1e-5` |
| `environment.json`、`runtime_settings.json` | CPU、Python、套件和執行緒設定 |
| `status.json`、`verification/verification.json` | 完成狀態與驗證結果 |

`comparison.csv` 只彙整 `repeat_1`、`repeat_2`、`repeat_3`，共 36 列結果，不含標題列；`run` 欄會標示來自哪次重跑。第一次獨立重現的 12 列摘要另存於 `independent_reproduction/summary.csv`。四次合共 48,000 筆原始計時；比較表不計算跨次平均或信賴區間。

## 6. 組員要交回甚麼

在同一個視窗把整個新結果資料夾打包：

```powershell
Compress-Archive -LiteralPath $resultRoot -DestinationPath ($resultRoot + '.zip')
if (-not $?) { throw 'ZIP creation failed. Keep the complete result folder.' }
Write-Host ('Return this ZIP: ' + $resultRoot + '.zip')
```

交回這個 ZIP，包含原始證據和環境紀錄；另外附一段簡短說明：

```text
操作人員：
自行建立環境：是 / 否
第一次獨立重現驗證：通過 / 失敗
之後三次同機重跑驗證：repeat_1 / repeat_2 / repeat_3 各自通過或失敗
日期、電源與背景負載：
是否有中斷、錯誤或條件改變：
觀察：ONNX 是否較快？關閉 ZipMap 是否較快？各次結果是否差異很大？
```

若失敗，也交回部分結果、錯誤訊息及實際執行的指令。不要刪除較慢或失敗的紀錄後只交最快的一次。

## 7. 如何比較，才不會解讀錯誤

- 第一次獨立重現：確認組員能自行建立環境，完整流程、預測一致性和驗證都通過。組員電腦與原實驗電腦的毫秒數及加速比可以不同，不需要重現原先約 483 倍的數字才算成功；即使 ONNX 較慢，也應保留並報告。
- 之後三次同機重跑：在同一電腦、相同 batch、相同 backend，逐次比較 `median_ms`、`p95_ms` 和 `speedup_vs_sklearn`；再查看各次 `results.md` 的 ZipMap 比率。正式穩定性比較使用這三次。
- 與原實驗電腦比較時分開呈現，不把不同電腦的結果混成同一台電腦的三次實驗。
- 100% 標籤一致率表示轉換前後答案一致；原先約 95.614% 才是分類正確率。機率容許有 `1e-5` 以內的差異，正確率也不是人工指定的通過門檻。
- 每次 12,000 筆是計時次數；獨立測試資料仍只有 114 筆。效能計時涵蓋暖機後的機率 API 呼叫及輸出建立，排除訓練、模型載入、session 建立、輸入準備、結果銷毀及正確性檢查所需的 ZipMap 字典轉矩陣。

## 常見問題

| 訊息或情況 | 處理方式 |
| --- | --- |
| `py` 找不到，或找不到 Python 3.12 | 安裝 64 位元 Python 3.12 及 Python Launcher，重新開啟 PowerShell |
| `No module named onnx_benchmark` | 確認目前在專案根目錄，並使用本專案 `.venv` 的 Python |
| 套件下載／版本安裝失敗 | 保留完整錯誤及 Python 版本交給組長，先不要改 lock 檔 |
| `Output directory is not empty` | 使用新批次路徑；不要覆寫或清空既有證據 |
| `Current source differs from the measured source` | 程式與該次結果版本不符；保留紀錄，使用一致版本重新做完整實驗 |
| 正確性或驗證失敗 | 保留該次整個資料夾和錯誤，停止效能結論，交由組長檢查 |
| 重開視窗後變數不存在 | 重新設定 `$memberId` 並完成第 3 節環境檢查，再執行第 4 節建立新批次；不用重建已安裝的環境 |

完成標準：同一位組員自行建立環境，在自己的同一台電腦先完成一次獨立重現，再完成三次同機重跑。四次均為完整實驗且通過驗證，交回包含四個實驗資料夾、36 列比較表及環境紀錄的完整 ZIP 和操作說明。
