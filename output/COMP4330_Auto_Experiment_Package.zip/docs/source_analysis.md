# Source analysis: Random Forest probability inference

This document analyzes the actual packages installed in the project's `.venv` on 14 October 2026: **scikit-learn 1.9.1**, **joblib 1.6.0**, **skl2onnx 1.20.0**, **ONNX 1.23.2**, and **ONNX Runtime 1.31.0**. It distinguishes inspected source code, exported graph structure, and runtime measurements. Numerical performance conclusions belong in [the measured results](../output/experiment/results.md).

## 1. scikit-learn's probability call

`RandomForestClassifier` inherits `ForestClassifier.predict_proba`. The installed implementation shows this path:

1. **Validate the fitted model and input.** `ForestClassifier.predict_proba`, `_forest.py:943-945`, calls `_validate_X_predict`. The latter, `_forest.py:606-625`, validates feature shape, requests `float32` input, and handles the estimator's missing-value support. Preparing `float32` arrays before timing does not remove the API's validation.
2. **Allocate accumulation buffers and dispatch trees.** `_forest.py:947-959` partitions estimators, allocates `float64` class-probability accumulation arrays, constructs a lock, and dispatches `_accumulate_prediction` through Python `joblib.Parallel`.
3. **Execute sequentially with `n_jobs=1`.** In the installed joblib source, `Parallel.__call__`, `parallel.py:2007-2012`, takes the sequential path. `_get_sequential_output`, `parallel.py:1936-1943`, calls each Python task directly. This setting avoids parallel worker execution; it still includes Python task iteration and dispatch costs.
4. **Call each compiled tree and accumulate its output.** `_accumulate_prediction`, `_forest.py:704-717`, invokes the tree's `predict_proba(X, check_input=False)` and adds its probabilities under the lock. `DecisionTreeClassifier.predict_proba`, `_classes.py:1047-1052`, delegates to `self.tree_.predict(X)` and selects the class columns.
5. **Traverse the tree in compiled code.** The installed `_tree` module is a `.pyd` binary, so `inspect` cannot provide its internal source lines. The verified upstream 1.9.1 Cython source, [`_tree.pyx:939-996`](https://github.com/scikit-learn/scikit-learn/blob/1.9.1/sklearn/tree/_tree.pyx#L939), shows `Tree.predict` obtaining leaf indices through `apply(X)` and selecting leaf values. Dense tree traversal follows feature thresholds under `nogil`. scikit-learn's tree traversal is therefore compiled, even though forest orchestration is in Python.
6. **Average across trees.** `_forest.py:961-965` divides the accumulated class probabilities by the number of estimators and returns the single-output matrix. For this project, that divisor is 100.

The benchmark measures this complete `predict_proba` API call. It does not isolate threshold comparisons or compiled tree traversal, and a backend timing difference cannot be attributed entirely to the tree algorithm.

## 2. Conversion and the actual ONNX graphs

In `convert_sklearn_random_forest_classifier`, installed `random_forest.py:152-179`, the converter assigns each fitted tree a weight of `1 / estimator_count` and encodes its nodes and class values into operator attributes. At `random_forest.py:267-274`, it adds an `ai.onnx.ml::TreeEnsembleClassifier` node with label and probability outputs. This encodes the fitted model; it does not retrain it.

`_parse_sklearn_classifier`, installed `_parse.py:537-576`, selects the probability representation. With `zipmap=False`, it returns the tensor output. Otherwise it applies the ZipMap parser. `convert_sklearn_zipmap`, installed `zip_map.py:45-74`, adds `ai.onnx.ml::ZipMap`. Its helper at `zip_map.py:15-42` also converts the label output, explaining the exported graph's additional `Cast` node.

The project requests target opsets **standard-domain 17** and **`ai.onnx.ml` 3**. These are requested compatibility ceilings, not proof of the versions actually imported into the exported graph. Direct inspection of both local `.onnx` files and [conversion.json](../output/experiment/conversion.json) gives:

| Variant | Exported nodes | Actual standard-domain import | Actual `ai.onnx.ml` import | Probability graph output |
| --- | --- | ---: | ---: | --- |
| `onnx_zipmap` | `TreeEnsembleClassifier`, `Cast`, `ZipMap` | 9 | 1 | `output_probability`: sequence of integer-keyed float maps |
| `onnx_tensor` | `TreeEnsembleClassifier` | 17 | 1 | `probabilities`: float tensor with two class columns |

The tensor graph's full `opset_import` list contains the standard-domain version 17 twice. The manifest preserves the original list separately from its convenient domain-to-version summary; a dictionary alone would hide the duplicate. The graphs are validated by the project, and the analysis reports their actual representation rather than forcing an upgrade to the requested ceiling.

The timed ONNX Runtime calls request only the probability graph output. This reduces requested Python return values, but it does **not** establish that the native classifier kernel skips every internal label calculation. The source and the output-fetch API do not justify that stronger claim.

## 3. ONNX Runtime's native CPU path

The local [runtime_settings.json](../output/experiment/runtime_settings.json) records `CPUExecutionProvider`, `ORT_SEQUENTIAL`, intra-op and inter-op thread settings of 1, and `ORT_ENABLE_ALL` graph optimization for both ONNX variants. The installed Python `Session.run`, `onnxruntime_inference_collection.py:372-405`, validates inputs and delegates to the native `_sess.run` binding.

The matching **v1.31.0** upstream tag was retrieved successfully over HTTPS. Its source supports the following descriptions:

- [`tree_ensemble_classifier.cc:13-39`](https://github.com/microsoft/onnxruntime/blob/v1.31.0/onnxruntime/core/providers/cpu/ml/tree_ensemble_classifier.cc#L13) registers native CPU classifier kernels for operator versions 1-2 and 3. [`Compute:61-71`](https://github.com/microsoft/onnxruntime/blob/v1.31.0/onnxruntime/core/providers/cpu/ml/tree_ensemble_classifier.cc#L61) obtains the input tensor, creates output tensors, and delegates to the tree-ensemble implementation.
- [`zipmap.cc:31-36`](https://github.com/microsoft/onnxruntime/blob/v1.31.0/onnxruntime/core/providers/cpu/ml/zipmap.cc#L31) registers a native CPU ZipMap kernel. For integer labels, [`Compute:98-109`](https://github.com/microsoft/onnxruntime/blob/v1.31.0/onnxruntime/core/providers/cpu/ml/zipmap.cc#L98) creates a vector of maps and inserts each class label and probability per input row. This changes output representation rather than training or improving the classifier.
- The Python binding's [`run:3068-3126`](https://github.com/microsoft/onnxruntime/blob/v1.31.0/onnxruntime/python/onnxruntime_pybind_state.cc#L3068) prepares native feeds, calls the native session, and converts fetched results into Python objects before returning. Tensor outputs use `AddTensorAsPyObj`; non-tensor outputs use `AddNonTensorAsPyObj`. At [`623-657`](https://github.com/microsoft/onnxruntime/blob/v1.31.0/onnxruntime/python/onnxruntime_pybind_state.cc#L623), the non-tensor path handles sequences of integer-keyed float maps.

These are release-source observations, supported by matching Python API text and observed graph/provider metadata. They are **not** kernel-level profiling of the installed native binary. This project does not verify its compiler flags, exact allocation counts, vectorization, cache behavior, or each kernel's share of elapsed time. Such properties must not be presented as measured explanations for a speedup.

## 4. What the benchmark can establish

The three variants use the same fitted forest and matched `float32` inputs, but their Python APIs and output representations differ. scikit-learn returns a probability matrix after Python forest dispatch and compiled tree calls. ONNX Runtime executes the converted graph and materializes its fetched tensor or sequence/map output through the native Python binding. The timer includes the API work and returned output construction; it excludes input preparation, model/session setup, output object destruction, and the project's dictionary-to-matrix normalization for correctness checks.

Consequently, the measured ZipMap on/off ratio compares the **whole probability-producing API path**, including graph execution and returned representation. It does not isolate the ZipMap operator's duration, nor prove that every difference comes from Python dictionaries. The graphs also differ in a label `Cast` and standard-domain imports; requesting probability output alone does not establish which label-branch work is pruned. Operator profiling or a separate controlled ablation would be required to make narrower causal claims.

Different accumulation and output precision can produce small probability differences. The inspected forest accumulates in `float64`, while the exported graph's probability output is float. The project therefore compares labels, accuracy, probability error, finiteness, and normalization in [correctness.json](../output/experiment/correctness.json) instead of inferring equivalence from format conversion alone.

Single-thread configuration improves comparability, but OS thread placement, CPU frequency, power mode, and concurrent activity remain uncontrolled. Fixed repeated input batches are synthetic performance loads; they add no independent accuracy cases. Results from this machine, dataset, and model are bounded observations, with timing variation reported, rather than a general claim that ONNX is always faster.

## 5. Source provenance

Installed files were imported with the project's `.venv/Scripts/python.exe`; Python symbol locations were obtained with `inspect.getsourcelines`. SHA-256 values below cover the exact installed bytes. Each link's target is the absolute installed path, making the inspected file unambiguous.

| ID | Installed file and symbols | SHA-256 |
| --- | --- | --- |
| S1 | [sklearn/ensemble/_forest.py](C:/Users/jason/Documents/cource/y4sem1/comp4330/scikit-learn_ONNX/.venv/Lib/site-packages/sklearn/ensemble/_forest.py): `BaseForest._validate_X_predict` 606-625; `_accumulate_prediction` 704-717; `ForestClassifier.predict_proba` 921-967 | `8c7941e9ce1a282138750833eef26ebc2d44715857281a5ed5a369d0887290b4` |
| S2 | [sklearn/tree/_classes.py](C:/Users/jason/Documents/cource/y4sem1/comp4330/scikit-learn_ONNX/.venv/Lib/site-packages/sklearn/tree/_classes.py): `DecisionTreeClassifier.predict_proba` 1023-1058 | `a78090f6d74800fe8584112b175095bb444b54f634f8468736cfbcb5af935cc2` |
| S3 | [joblib/parallel.py](C:/Users/jason/Documents/cource/y4sem1/comp4330/scikit-learn_ONNX/.venv/Lib/site-packages/joblib/parallel.py): `Parallel._get_sequential_output` 1914-1954; `Parallel.__call__` 1995-2098 | `431586528ca1a069cd96a960f10c424a82bedb1a7eacd3c239e9165611a2e44f` |
| S4 | [skl2onnx/operator_converters/random_forest.py](C:/Users/jason/Documents/cource/y4sem1/comp4330/scikit-learn_ONNX/.venv/Lib/site-packages/skl2onnx/operator_converters/random_forest.py): `convert_sklearn_random_forest_classifier` 105-435 | `50e460a8049e5ac876b05e664f05bf7006440b4bc38be01a643d4d1a5cffb5c3` |
| S5 | [skl2onnx/_parse.py](C:/Users/jason/Documents/cource/y4sem1/comp4330/scikit-learn_ONNX/.venv/Lib/site-packages/skl2onnx/_parse.py): `_parse_sklearn_classifier` 537-576 | `c063689f96258a56de24c1fd3f341e53307c2d3a7f6b1bbac317c6bb4a55cbf0` |
| S6 | [skl2onnx/operator_converters/zip_map.py](C:/Users/jason/Documents/cource/y4sem1/comp4330/scikit-learn_ONNX/.venv/Lib/site-packages/skl2onnx/operator_converters/zip_map.py): `_common_convert_sklearn_zipmap` 15-42; `convert_sklearn_zipmap` 45-74 | `8d929d938e2cf440eab69bac9f822e419dd6dec61e39470d5ddc3748bed067ad` |
| S7 | [onnxruntime/capi/onnxruntime_inference_collection.py](C:/Users/jason/Documents/cource/y4sem1/comp4330/scikit-learn_ONNX/.venv/Lib/site-packages/onnxruntime/capi/onnxruntime_inference_collection.py): `Session.run` 372-405 | `caa5b378e0c8d02654d912d3e6cfcee18a71a62037568c350aea00a70d2c9ec3` |
| S8 | [sklearn/tree/_tree.cp312-win_amd64.pyd](C:/Users/jason/Documents/cource/y4sem1/comp4330/scikit-learn_ONNX/.venv/Lib/site-packages/sklearn/tree/_tree.cp312-win_amd64.pyd): installed native tree extension; internal source lines unavailable | `4fc913357d7581966366c6ab8234be39a843282083159a23a213af1bdf2d4a93` |
| S9 | [onnxruntime/capi/onnxruntime_pybind11_state.pyd](C:/Users/jason/Documents/cource/y4sem1/comp4330/scikit-learn_ONNX/.venv/Lib/site-packages/onnxruntime/capi/onnxruntime_pybind11_state.pyd): installed native runtime binding; internal source lines unavailable | `f514d95a3095e85a3708ba051f8747edd8e4b968fb7b86f6e3478e1df3292d76` |

All upstream URLs in the following table returned HTTP 200 when checked. The links pin release tags; the hashes pin the exact downloaded text. Upstream S1, S2, and S7 use LF while their installed copies use CRLF; their decoded lines were compared and are identical, explaining different byte hashes. Upstream S3-S6 match their installed byte hashes exactly. Native source correspondence is by release tag, not a proven reproducible native-wheel build.

| Upstream release source | Retrieved source SHA-256 |
| --- | --- |
| [scikit-learn 1.9.1 `_forest.py`](https://raw.githubusercontent.com/scikit-learn/scikit-learn/1.9.1/sklearn/ensemble/_forest.py) | `ddf75afd3c1fb4d1b29e5154436ec1684e8969bffed4eef4718af53e2260ca7c` |
| [scikit-learn 1.9.1 `_classes.py`](https://raw.githubusercontent.com/scikit-learn/scikit-learn/1.9.1/sklearn/tree/_classes.py) | `12d05b5c28d0c4bb5f6dd166354842f6d3895b33066c4491a953d0a648525794` |
| [scikit-learn 1.9.1 `_tree.pyx`](https://raw.githubusercontent.com/scikit-learn/scikit-learn/1.9.1/sklearn/tree/_tree.pyx) | `531c4937fa67d32cf7f0ab75174dd4893da0c8cd15f245ff36a4bb3dfba0fe78` |
| [joblib 1.6.0 `parallel.py`](https://raw.githubusercontent.com/joblib/joblib/1.6.0/joblib/parallel.py) | `431586528ca1a069cd96a960f10c424a82bedb1a7eacd3c239e9165611a2e44f` |
| [skl2onnx 1.20.0 `random_forest.py`](https://raw.githubusercontent.com/onnx/sklearn-onnx/1.20.0/skl2onnx/operator_converters/random_forest.py) | `50e460a8049e5ac876b05e664f05bf7006440b4bc38be01a643d4d1a5cffb5c3` |
| [skl2onnx 1.20.0 `_parse.py`](https://raw.githubusercontent.com/onnx/sklearn-onnx/1.20.0/skl2onnx/_parse.py) | `c063689f96258a56de24c1fd3f341e53307c2d3a7f6b1bbac317c6bb4a55cbf0` |
| [skl2onnx 1.20.0 `zip_map.py`](https://raw.githubusercontent.com/onnx/sklearn-onnx/1.20.0/skl2onnx/operator_converters/zip_map.py) | `8d929d938e2cf440eab69bac9f822e419dd6dec61e39470d5ddc3748bed067ad` |
| [ORT v1.31.0 `onnxruntime_inference_collection.py`](https://raw.githubusercontent.com/microsoft/onnxruntime/v1.31.0/onnxruntime/python/onnxruntime_inference_collection.py) | `55fa6aacb08799004503b04809edfc2efd23a2c09b74ce344478e7d75a70293b` |
| [ORT v1.31.0 `tree_ensemble_classifier.cc`](https://raw.githubusercontent.com/microsoft/onnxruntime/v1.31.0/onnxruntime/core/providers/cpu/ml/tree_ensemble_classifier.cc) | `72247de06649e6d63d9f45b7c4e4a1177422f4578971917160e5da7157e70c8f` |
| [ORT v1.31.0 `zipmap.cc`](https://raw.githubusercontent.com/microsoft/onnxruntime/v1.31.0/onnxruntime/core/providers/cpu/ml/zipmap.cc) | `f9205124962c59fcaf2f56aee5e0f47af05a7f21b2bb897e0e08dc39ef7f481a` |
| [ORT v1.31.0 `onnxruntime_pybind_state.cc`](https://raw.githubusercontent.com/microsoft/onnxruntime/v1.31.0/onnxruntime/python/onnxruntime_pybind_state.cc) | `544788e1475ad16348a48adfc116d0c0d6644de37341e3391e10e7ac0f9b42bc` |
