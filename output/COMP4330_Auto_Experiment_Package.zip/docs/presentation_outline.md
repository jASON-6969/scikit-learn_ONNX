# Evaluating CPU Inference Performance of scikit-learn and ONNX Runtime

Six-minute English presentation outline, based on the completed local run dated 14 October 2026. This is a slide specification and speaker guide, not a rendered PowerPoint deck. Replace Member 1-5 with actual names and IDs. All five members should speak and attend Q&A.

## Slide sequence and timing

| Slide | Time | Speaker placeholder | Core message and visual |
| --- | --- | --- | --- |
| 1. Problem and research questions | 00:00-00:40 (40 s) | Member 1, group leader | Can conversion reduce CPU probability-inference latency without changing predictions? Compare scikit-learn, ORT ZipMap on and ORT ZipMap off across four batch sizes. |
| 2. One model, three execution paths | 00:40-01:40 (60 s) | Member 2 | One 100-tree forest; 455 training and 114 held-out samples, stratified seed 42; identical contiguous float32 inputs. Show trained forest -> original estimator / two converted graphs. Python forest dispatch coexists with compiled scikit-learn tree traversal. |
| 3. Fair measurement and its boundaries | 01:40-02:50 (70 s) | Member 3 | Single-thread CPU execution, prepared inputs, 50 warm-ups, 10 rotating rounds of 100 calls, 12 cells. Time probability APIs and returned output construction. Exclude training/setup, destruction and dictionary-to-matrix normalization. Synthetic repeated batches are timing loads. |
| 4. Correctness first | 02:50-03:35 (45 s) | Member 4 | All 114 original test cases: 100% label agreement; accuracy 95.6140% for all variants; maximum probability error 6.55651e-7, below 1e-5. Equal accuracy alone would not establish equivalence. |
| 5. Measured performance and ZipMap | 03:35-05:05 (90 s) | Member 5 | Show latency and throughput; tensor-output ORT speedup 482.93x, 157.48x, 42.41x, 9.95x for batches 1,16,64,256. ZipMap on/off median latency ratios are 1.108x-1.181x, favoring off with a 9.70%-15.31% latency reduction. Discuss spread and workload limits. |
| 6. Recommendation and limits | 05:05-06:00 (55 s) | Member 1 | For this probability-matrix workload, prefer the converted tensor output after correctness validation. This run does not establish universal acceleration or an isolated ZipMap cost. List one model/machine, repeated inputs, uncontrolled power/placement and future independent rerun/profiling. |

Total presentation time: 360 seconds. Reserve the additional course Q&A period of 2-3 minutes; it is separate from these six minutes.

## Key speaker notes

- Slide 2: scikit-learn 1.9.1 orchestrates trees in Python/joblib, but each tree's traversal is compiled Cython. ORT 1.31.0 uses a native CPU tree-ensemble path. Source inspection supports this distinction; it does not measure each operation's time. Cite [source_analysis.md](source_analysis.md) and its release-tag links.
- Slide 3: scikit-learn uses `predict_proba`; ORT requests only the probability graph output. ZipMap returns sequence/map objects; disabling it returns a tensor. Requesting probabilities does not prove that the native classifier skips internal label work.
- Slide 3: both conversions requested standard opset 17 and `ai.onnx.ml` 3. Actual imports were standard 9 / ML 1 for ZipMap on, standard 17 / ML 1 for off, with a duplicate standard-17 entry in the tensor graph. Cite the actual exported graph, not the requested ceiling. Keep the import detail in a backup slide or Q&A note.
- Slide 3: one thread was configured using estimator/runtime settings and native-library limits. The machine is an AMD Ryzen AI 7 H 350, Windows 11, Python 3.12.10. CPU power mode, frequency, concurrent activity and processor affinity were not controlled.
- Slide 5: the large batch-1 speedup is an API measurement with noticeable variation, not evidence that the underlying tree algorithm alone became 483 times faster. scikit-learn's batch-1 median is higher than batch-16 in this run; disclose that non-monotonicity and avoid a universal scaling claim.
- Slide 5: ZipMap-off and ZipMap-on interquartile ranges overlap at batches 1,64,256. Their median ratios are descriptive and do not establish statistical significance across independent runs. The graphs differ beyond the probability format, so a narrower causal attribution needs profiling or an ablation.

## Figures and data to place on slides

- Slide 4: small correctness table from [correctness.json](../output/experiment/correctness.json).
- Slide 5: [latency chart](../output/experiment/figures/latency.png), [throughput chart](../output/experiment/figures/throughput.png) and [ZipMap comparison](../output/experiment/figures/zipmap_speedup.png). Prioritize readable latency and ZipMap panels; keep throughput as backup if the slide becomes crowded.
- Backup: all 12 configurations from [summary.csv](../output/experiment/summary.csv), timing quantiles, actual graph imports and source-path references.

## Q&A preparation

| Likely question | Evidence-based answer |
| --- | --- |
| Why use the same model? | Retraining or tuning different models would confound runtime with model quality/structure. Both ONNX artifacts encode the one fitted forest. |
| Did you train on the test set? | No. Training uses 455 saved training indices; accuracy and agreement use 114 distinct held-out indices. Repeated performance inputs add no independent accuracy samples. |
| Why float32 and one thread? | Match ONNX input representation and limit threading as a confound. Input preparation is outside timing, API validation remains inside. It is a chosen execution condition, not a claim that one thread is optimal. |
| What is ZipMap doing? | It changes probabilities into class-keyed map outputs. Tensor output avoids that representation. Both retain predictions within the tested tolerance. |
| Is the timing comparison identical computation? | It is a controlled comparison of native probability-return APIs. Dispatch, graph execution and returned representation are timed. Dictionary normalization and output destruction are excluded; downstream consumers may pay additional costs. |
| Why such a large speedup? | The measured whole-call paths differ. Inspected source shows Python forest orchestration versus native graph execution, but there is no operator profile establishing the precise contribution. Ratio magnitudes are limited to this run. |
| Do opset 17 and ML 3 describe both files? | They were requested ceilings. The manifests preserve each file's actual imports, which are older/different, and the duplicate tensor import. Both files passed checking and executed. |
| Is ZipMap always slower? | This run's medians favor off by about 9.7%-15.3%. Overlapping timing spreads and graph differences prevent a general or operator-only claim. |
| Is 95.6% accuracy a clinical claim? | No. This is a small computational case study of conversion fidelity and inference APIs, not a clinical evaluation. |
| What remains before final submission? | Fill team identity, independently repeat the saved procedure, review results and source evidence, polish the six-minute deck and submit the English report within the course word limit. |

## References and submission preparation

Use the verified sources in [source_analysis.md](source_analysis.md) and [final_report_draft.md](final_report_draft.md), keeping release versions visible on the source-analysis slide. The initial slide deadline is 15 November 2026 at 23:59 Hong Kong time. Rehearse transitions with all five speakers and keep the full table/source details as backup material.
