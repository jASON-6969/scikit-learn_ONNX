# Evaluating CPU Inference Performance of scikit-learn and ONNX Runtime

**COMP 4330SEF report draft | Local experiment: 14 October 2026**

Tutorial group: ____________________ | Project group: ____________________

Member names and student IDs: ___________________________________________________

Group leader: ____________________

## Abstract

This study evaluates CPU probability inference for one trained Random Forest using scikit-learn and ONNX Runtime, with ZipMap enabled and disabled. A stratified 80/20 split of the Breast Cancer Wisconsin dataset yielded 455 training and 114 held-out samples. We measured four batch sizes with single-thread settings, 50 warm-ups and 1,000 calls per configuration. Both converted models achieved complete label agreement with scikit-learn and maximum probability error of 6.55651e-7. Tensor-output ONNX Runtime was 9.95-482.93 times faster by median call latency in this local experiment; disabling ZipMap reduced median latency by 9.70%-15.31%. Source inspection identifies distinct orchestration and output paths but does not isolate their individual costs. Conclusions apply to this model, machine and warmed synthetic workloads, with uncontrolled CPU power conditions and timing variability limiting generalization.

## 1. Introduction and background

A trained machine-learning model may be called repeatedly in an application, making inference latency relevant alongside predictive accuracy. Converting a scikit-learn estimator to ONNX changes its execution and output paths. Conversion should therefore be assessed for prediction fidelity and practical performance rather than assumed to accelerate every workload.

This project studies the same fitted Random Forest through three probability-producing APIs: scikit-learn, ONNX Runtime (ORT) with ZipMap, and ORT returning a probability tensor. The questions are how batch size affects latency/throughput, whether conversion preserves predictions, and whether disabling ZipMap improves the measured API path. The proposed software improvement changes output representation without retraining or tuning the classifier.

## 2. Literature and open-source analysis

scikit-learn's Random Forest API supplies classification and probability inference [1]. Its inspected 1.9.1 source validates input, allocates float64 probability accumulators, dispatches trees through joblib and averages their outputs. At `n_jobs=1`, joblib follows its sequential path. Each tree still executes compiled traversal; the release Cython source shows threshold traversal and leaf-value selection [2]. Describing scikit-learn inference as entirely interpreted Python would therefore be inaccurate.

sklearn-onnx encodes the fitted forest into `ai.onnx.ml::TreeEnsembleClassifier`, weighting each of the 100 trees by 1/100. Its parser returns the probability tensor when ZipMap is disabled; otherwise the converter adds ZipMap and a label Cast [3]. The official ZipMap example motivates examining the representation tradeoff [4]; its example timings are not our results.

ORT's matching v1.31.0 CPU source registers native tree-ensemble and ZipMap kernels. The ZipMap implementation constructs class-keyed maps; the Python binding converts fetched native outputs into Python objects before returning [5]. Detailed installed-file hashes, release links and exact symbol lines are preserved in [source_analysis.md](source_analysis.md). These observations identify execution paths, not each kernel's measured contribution or the native wheel's compiler optimizations.

## 3. Methodology and implementation

### 3.1 Fixed data and model

The scikit-learn Breast Cancer Wisconsin (Diagnostic) loader supplies 569 samples, 30 numeric features and two classes [6]. A seed-42 stratified 80/20 split created 455 training and 114 test cases. Saved indices preserve the split. Features are contiguous float32; training uses only the training partition.

One `RandomForestClassifier(n_estimators=100, random_state=42, n_jobs=1)` was fitted and saved. The baseline reloads that artifact; both ONNX graphs derive from the same fitted forest. There is no hyperparameter search. Original test cases support accuracy and equivalence checks; fixed shuffled/repeated test inputs supply batches 1,16,64,256 for performance. Repetition creates synthetic loads, not additional accuracy cases.

Both conversions requested standard-domain opset 17 and `ai.onnx.ml` 3 as compatibility ceilings. Actual imports differ: ZipMap-on uses standard 9 / ML 1; tensor output uses standard 17 / ML 1 and contains a duplicate standard-17 import. The original lists are retained in [conversion.json](../output/experiment/conversion.json). Both files passed ONNX checking and executed in ORT; requested versions should not be substituted for actual graph imports.

### 3.2 Execution and measurement boundaries

The experiment ran on an AMD Ryzen AI 7 H 350 (8 cores,16 logical processors), Windows 11 and Python 3.12.10. Versions include scikit-learn 1.9.1, skl2onnx 1.20.0, ONNX 1.23.2 and ORT 1.31.0. scikit-learn used `n_jobs=1`; ORT used CPUExecutionProvider, sequential execution, intra/inter-op threads 1 and graph optimization enabled. Native-library environment settings and observed threadpools were limited to one thread. Processor affinity and CPU power conditions were not controlled.

For each of 12 cells, 50 warm-ups preceded 10 rounds of 100 calls. Variant order rotated across rounds. `perf_counter_ns` measured each call. Inputs, feeds and output names were prepared beforehand. The timer includes `predict_proba` or ORT probability-output `session.run`, including returned Python output construction. It excludes training, conversion, loading/session creation, input preparation, output destruction and dictionary-to-matrix normalization used for correctness.

This compares native probability-return APIs, not identical downstream formats or pure tree computation. Requesting only probability outputs does not establish that the classifier skips internal label work. ZipMap-on/off graphs differ in representation, label Cast and standard-domain imports; their timing ratio does not isolate one operator's duration.

### 3.3 Correctness and metrics

Before timing, the pipeline checked output alignment, labels, finite/bounded probabilities, row normalization and maximum absolute error against scikit-learn. Required label agreement was 100%, with probability tolerance 1e-5. It checked the original held-out set and performance batches, using the former alone for accuracy.

Each cell retains 1,000 raw call timings. We report median, P25/P75 and P95 latency. Throughput is batch size divided by median seconds; speedup is the matching scikit-learn median divided by an ORT median. Quantiles describe this run's spread rather than confidence intervals across independent experiments.

## 4. Results and discussion

### 4.1 Prediction fidelity

Both converted variants agreed with every scikit-learn label on the 114 original held-out cases. All three achieved 95.6140% accuracy (109/114). ONNX probability error was at most 6.55651e-7, below 1e-5; finiteness, bounds and normalization checks passed. Equal aggregate accuracy alone would not establish prediction equivalence, so agreement and probability checks are reported separately. This is computational conversion evidence, not clinical validation.

### 4.2 Inference performance

Table 1 contains all 12 measured cells. ORT tensor-output median latency was 0.00970,0.01660,0.07620,0.64045 ms at batches 1,16,64,256, respectively, yielding speedups of 482.93x,157.48x,42.41x,9.95x. Tensor throughput peaked among the tested batches at batch 16 (963,855 samples/s) and fell to 399,719 at batch 256. Larger batches therefore did not always improve throughput.

The substantial small-batch ratio concerns the complete API paths, including scikit-learn's validation and Python forest orchestration. Source inspection makes those differences relevant, but no operator profile proves their exact contribution. The scikit-learn batch-1 median exceeded batch-16, and several timing distributions were broad. We preserve this non-monotonic result rather than smoothing it into an assumed scaling pattern.

### 4.3 Output-format improvement

Disabling ZipMap reduced median latency by 9.77%,15.31%,14.96%,9.70% across the four batch sizes; on/off ratios were 1.1082x,1.1807x,1.1759x,1.1074x. Tensor output is therefore the practical local choice when consumers require a probability matrix. ZipMap may remain appropriate when a consumer needs class-keyed maps.

Interquartile ranges overlap for batches 1,64,256. The ratios are descriptive, not statistical significance claims across independent runs. Additional normalization costs depend on the downstream consumer. Profiling and a more tightly controlled graph ablation would be required to attribute the difference specifically to ZipMap.

### 4.4 Limitations

This study covers one small dataset, one 100-tree model and one CPU machine. Fixed repeated inputs and warmed sessions differ from changing production requests and cold starts. Thread settings were controlled, but CPU frequency, power policy, concurrent workload and scheduling were not. Setup durations were recorded once separately and cannot characterize a cold-start distribution. Independent reruns and additional workloads are needed before wider deployment claims.

## 5. Conclusion

The saved conversions preserved the tested labels and probability tolerance. ORT was faster by median latency in every tested configuration, and tensor output improved the local ZipMap-on median by about 9.7%-15.3%. The recommendation is to validate conversion first, choose an output format that matches the consumer, and benchmark the complete intended API under documented conditions. This evidence supports that local recommendation without establishing universal ONNX acceleration.

## References

[1] scikit-learn developers. *RandomForestClassifier* and release 1.9.1 probability implementation. [API](https://scikit-learn.org/stable/modules/generated/sklearn.ensemble.RandomForestClassifier.html); [`_forest.py:921-967`](https://github.com/scikit-learn/scikit-learn/blob/1.9.1/sklearn/ensemble/_forest.py#L921).

[2] scikit-learn developers. Release 1.9.1 compiled tree implementation, [`_tree.pyx:939-996`](https://github.com/scikit-learn/scikit-learn/blob/1.9.1/sklearn/tree/_tree.pyx#L939).

[3] sklearn-onnx contributors. Release 1.20.0 [`random_forest.py:152-179,267-274`](https://github.com/onnx/sklearn-onnx/blob/1.20.0/skl2onnx/operator_converters/random_forest.py#L152), [`_parse.py:537-576`](https://github.com/onnx/sklearn-onnx/blob/1.20.0/skl2onnx/_parse.py#L537), [`zip_map.py:15-74`](https://github.com/onnx/sklearn-onnx/blob/1.20.0/skl2onnx/operator_converters/zip_map.py#L15).

[4] sklearn-onnx contributors. *Probabilities as a vector or as a ZipMap*. [Official example](https://onnx.ai/sklearn-onnx/auto_examples/plot_convert_zipmap.html).

[5] ONNX Runtime contributors. v1.31.0 [`tree_ensemble_classifier.cc:61-71`](https://github.com/microsoft/onnxruntime/blob/v1.31.0/onnxruntime/core/providers/cpu/ml/tree_ensemble_classifier.cc#L61), [`zipmap.cc:98-109`](https://github.com/microsoft/onnxruntime/blob/v1.31.0/onnxruntime/core/providers/cpu/ml/zipmap.cc#L98), [`onnxruntime_pybind_state.cc:3068-3126`](https://github.com/microsoft/onnxruntime/blob/v1.31.0/onnxruntime/python/onnxruntime_pybind_state.cc#L3068); [thread management](https://onnxruntime.ai/docs/performance/tune-performance/threading.html).

[6] scikit-learn developers. *load_breast_cancer*. [Official dataset documentation](https://scikit-learn.org/stable/modules/generated/sklearn.datasets.load_breast_cancer.html).

Sources accessed 14 October 2026. [source_analysis.md](source_analysis.md) records exact installed/retrieved source hashes and distinguishes release-source correspondence from native-binary profiling.

## Work allocation

Role placeholders require actual names/IDs and confirmation of contributions before submission. They do not assert that these people independently completed the delivered draft.

| Member | Responsibility |
| --- | --- |
| Member 1, group leader | Proposal/report integration, evidence review and submission coordination |
| Member 2 | Dataset/model and scikit-learn implementation analysis |
| Member 3 | Conversion, graph/output analysis and correctness |
| Member 4 | Benchmark, environment and reproducibility |
| Member 5 | Charts, presentation and interpretation |

## Appendix: figures, full table and evidence

Table 1. Twelve measured configurations. Each contains 1,000 timed calls. P25-P75 is the interquartile range. Values are rounded for readability; [summary.csv](../output/experiment/summary.csv) retains precision.

| Runtime | Batch | Median ms | P25-P75 ms | P95 ms | Samples/s | Speedup |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| scikit-learn | 1 | 4.68440 | 3.17158-6.92070 | 12.19507 | 213 | 1.00x |
| ZipMap on | 1 | 0.01075 | 0.00790-0.01350 | 0.04113 | 93,023 | 435.76x |
| ZipMap off | 1 | 0.00970 | 0.00758-0.01340 | 0.03623 | 103,093 | 482.93x |
| scikit-learn | 16 | 2.61425 | 2.34353-3.22698 | 4.10991 | 6,120 | 1.00x |
| ZipMap on | 16 | 0.01960 | 0.01950-0.02050 | 0.03970 | 816,327 | 133.38x |
| ZipMap off | 16 | 0.01660 | 0.01640-0.01720 | 0.02761 | 963,855 | 157.48x |
| scikit-learn | 64 | 3.23200 | 2.49928-3.87648 | 5.21484 | 19,802 | 1.00x |
| ZipMap on | 64 | 0.08960 | 0.06140-0.10623 | 0.17732 | 714,286 | 36.07x |
| ZipMap off | 64 | 0.07620 | 0.05150-0.08650 | 0.10982 | 839,895 | 42.41x |
| scikit-learn | 256 | 6.37035 | 5.18603-8.80370 | 11.54086 | 40,186 | 1.00x |
| ZipMap on | 256 | 0.70925 | 0.51153-1.10340 | 1.59343 | 360,945 | 8.98x |
| ZipMap off | 256 | 0.64045 | 0.41920-0.97515 | 1.39473 | 399,719 | 9.95x |

Figure 1. Median call latency with observed interquartile spread; API timing boundaries apply.

![Latency and interquartile range](../output/experiment/figures/latency.png)

Figure 2. Batch size divided by median call latency; this is a derived warmed-workload rate.

![Throughput](../output/experiment/figures/throughput.png)

Figure 3. ZipMap-on median divided by ZipMap-off median; above 1 favors tensor output.

![ZipMap comparison](../output/experiment/figures/zipmap_speedup.png)

Evidence files: [config.json](../output/experiment/config.json), [correctness.json](../output/experiment/correctness.json), [environment.json](../output/experiment/environment.json), [conversion.json](../output/experiment/conversion.json), [runtime_settings.json](../output/experiment/runtime_settings.json), [raw timings](../output/experiment/timings.csv), [provenance](../output/experiment/provenance.json). Completion state was `complete` when this draft was prepared. Reproduction and saved-run verification commands are in [README.md](../README.md).

Editorial checklist: replace team identity, confirm actual work allocation, independently rerun/review evidence, polish language/layout, and retain the course's maximum 2,000 counted words and 100-150-word abstract. References, tables, figures, allocation and appendix are excluded under the supplied course rules. The English report draft is not a final submitted PDF.
